public class NumberThread extends Thread {

    private final Counter counter;

    public NumberThread(Counter counter) {
        this.counter = counter;
    }

    @Override
    public void run() {
        for (int i = 1; i <=10; i++) {
            counter.increment();
            System.out.println(i);
            try {
                // 스레드 실행 속도를 조절하여 다른 스레드와 번갈아 실행되도록 함
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
