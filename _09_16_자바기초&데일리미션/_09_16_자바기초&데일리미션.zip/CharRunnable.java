public class CharRunnable implements Runnable {

    private final Counter counter;

    public CharRunnable(Counter counter) {
        this.counter = counter;
    }

    @Override
    public void run() {
        for (char i = 'A'; i <= 'J'; i++) {
            System.out.println(i);
            counter.increment();
            try {
                // 스레드 실행 속도를 조절하여 다른 스레드와 번갈아 실행되도록 함
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }
}