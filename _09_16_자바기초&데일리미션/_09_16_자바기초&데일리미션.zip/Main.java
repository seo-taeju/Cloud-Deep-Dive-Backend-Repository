public class Main {
    public static void main(String[] args) {

        Counter sharedCounter = new Counter();

        // Thread 클래스를 상속받은 객체 생성 및 시작
        NumberThread numberThread = new NumberThread(sharedCounter);
        // Runnable 인터페이스를 구현한 객체를 Thread 생성자에 전달하여 스레드 생성 및 시작
        Thread charThread = new Thread(new CharRunnable(sharedCounter));

        numberThread.start();
        charThread.start();

        //선택심화, \- join()을 사용해 두 스레드가 모두 끝난 후 “모든 스레드 종료” 메시지를 출력하세요.
        try {
            numberThread.join();
            charThread.join();
            System.out.printf("모든 스레드 종료");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("최종 카운트: " + sharedCounter.getCount());

        
    }
}
