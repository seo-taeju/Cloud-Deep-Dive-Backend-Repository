public class Counter {

    private int count = 0;

    // 동기화된 메서드: 한 번에 한 스레드만 접근 가능
    public synchronized void increment() {
        count++;
        System.out.println(Thread.currentThread().getName() + " - " + count);
    }

    public int getCount() {
        return count;
    }
}
